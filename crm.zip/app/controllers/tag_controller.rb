class TagController < ApplicationController
  def index
  end
end
