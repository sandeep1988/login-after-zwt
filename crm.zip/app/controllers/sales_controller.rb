class SalesController < ApplicationController
  before_action :set_sale, only: [:show, :edit, :update, :destroy]
  layout "application"
  # GET /sales
  # GET /sales.json
  def index
    @sales = Sale.all
  end

  # GET /sales/1
  # GET /sales/1.json
  def show
  end

  # GET /sales/new
  def new
  end

  # GET /sales/1/edit
  def edit
  end

  # POST /sales
  # POST /sales.json
  def create
  end

  def welcome
    @sales = User.create!(:email => params[:email], :password => params[:password], :v_firstname => params[:v_firstname], :v_lastname => params[:v_lastname], :v_im_skype=> params[:v_im_skype], :v_im_password => params[:v_im_password], :v_gmail=>params[:v_gmail], :v_linkedin_url=> params[:v_linkedin_url], :v_phone=>params[:v_phone])
        if @sales.nil?
          debugger
          redirect_to root_path
        else 
          redirect_to new_sale_path
        end
  end
  # PATCH/PUT /sales/1
  # PATCH/PUT /sales/1.json
  def update
    respond_to do |format|
      if @sale.update(sale_params)
        format.html { redirect_to @sale, notice: 'Sale was successfully updated.' }
        format.json { render :show, status: :ok, location: @sale }
      else
        format.html { render :edit }
        format.json { render json: @sale.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /sales/1
  # DELETE /sales/1.json
  def destroy
    @sale.destroy
    respond_to do |format|
      format.html { redirect_to sales_url, notice: 'Sale was successfully destroyed.' }
      format.json { head :no_content }
    end
  end
  
  def my_profile
  end
  
  def dashboard
  end
  
  def search
  end

  def list_ajax
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sale
      @sale = Sale.find(1)
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def sale_params
      params.require(:sale).permit(:username, :password)
    end
end
