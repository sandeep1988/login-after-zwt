class Followuptype < ActiveRecord::Base
end
